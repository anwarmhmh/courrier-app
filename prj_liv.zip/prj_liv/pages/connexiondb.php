<?php
$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "prjliv";
    $conn = mysqli_connect($hostname, $username, $password, $databaseName);

?>