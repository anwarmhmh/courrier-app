<?php
    header("location:pages/Client.php");
?>